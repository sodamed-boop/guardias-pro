import 'package:intl/intl.dart';

String fmtDate(DateTime dt) => DateFormat('EEE d MMM', 'es').format(dt);
String fmtDateLong(DateTime dt) => DateFormat('EEEE d MMMM y', 'es').format(dt);
String fmtTime(DateTime dt) => DateFormat('HH:mm').format(dt);

String fmtRange(DateTime start, DateTime end) {
  final s = fmtTime(start);
  final e = fmtTime(end);
  return '$s–$e';
}

String fmtRangeWithDay(DateTime start, DateTime end) {
  final sameDay = start.year == end.year && start.month == end.month && start.day == end.day;
  if (sameDay) return '${fmtDateLong(start)} · ${fmtRange(start, end)}';
  return '${fmtDateLong(start)} ${fmtTime(start)} → ${fmtDateLong(end)} ${fmtTime(end)}';
}

String fmtDurationShort(Duration d) {
  final h = d.inMinutes ~/ 60;
  final m = d.inMinutes % 60;
  if (m == 0) return '${h}h';
  return '${h}h ${m}m';
}
