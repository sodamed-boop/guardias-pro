import 'package:home_widget/home_widget.dart';
import '../data/models.dart';
import '../utils/datetime.dart';

class WidgetSyncService {
  static const _androidWidgetName = 'NextShiftWidgetProvider';

  static Future<void> updateNextShiftWidget({
    required Shift? nextShift,
    required List<Workplace> workplaces,
  }) async {
    try {
      if (nextShift == null) {
        await HomeWidget.saveWidgetData<String>('next_title', 'Sin guardias próximas');
        await HomeWidget.saveWidgetData<String>('next_subtitle', 'Agregá una guardia para verla acá');
        await HomeWidget.saveWidgetData<int>('next_color', 0xFF616161);
      } else {
        final w = workplaces.firstWhere((x) => x.id == nextShift.workplaceId);
        final title = '${w.alias} · ${fmtRange(nextShift.start, nextShift.end)}';
        final subtitle = fmtDateLong(nextShift.start);
        await HomeWidget.saveWidgetData<String>('next_title', title);
        await HomeWidget.saveWidgetData<String>('next_subtitle', subtitle);
        await HomeWidget.saveWidgetData<int>('next_color', w.colorValue);
      }
      await HomeWidget.updateWidget(androidName: _androidWidgetName);
    } catch (_) {
      // best-effort; ignore failures
    }
  }
}
