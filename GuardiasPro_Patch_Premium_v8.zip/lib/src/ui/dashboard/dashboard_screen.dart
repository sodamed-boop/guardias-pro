import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../data/providers.dart';
import '../../data/models.dart';
import '../../utils/datetime.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final workplacesAsync = ref.watch(workplacesProvider);
    final nextAsync = ref.watch(nextShiftProvider);
    final upcomingAsync = ref.watch(upcomingShiftsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Guardias Pro'),
        actions: [
          IconButton(
            tooltip: 'Agregar guardia',
            onPressed: () => context.push('/shift/new'),
            icon: const Icon(Icons.add_circle_outline),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          ref.invalidate(workplacesProvider);
          ref.invalidate(upcomingShiftsProvider);
          ref.invalidate(nextShiftProvider);
        },
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          children: [
            workplacesAsync.when(
              data: (workplaces) => nextAsync.when(
                data: (nextShift) => _NextShiftCard(shift: nextShift, workplaces: workplaces),
                loading: () => const _SkeletonCard(),
                error: (e, _) => _ErrorCard(message: e.toString()),
              ),
              loading: () => const _SkeletonCard(),
              error: (e, _) => _ErrorCard(message: e.toString()),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => context.push('/shift/new'),
                    icon: const Icon(Icons.add),
                    label: const Text('Nueva guardia'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => context.go('/calendar'),
                    icon: const Icon(Icons.calendar_month),
                    label: const Text('Ver mes'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Text('Próximas guardias', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            upcomingAsync.when(
              data: (list) {
                final take = list.take(8).toList();
                if (take.isEmpty) {
                  return const _EmptyState(text: 'No hay guardias próximas. Agregá una con “Nueva guardia”.');
                }
                return workplacesAsync.when(
                  data: (workplaces) => Column(
                    children: [
                      for (final s in take) _UpcomingTile(shift: s, workplaces: workplaces),
                    ],
                  ),
                  loading: () => const SizedBox.shrink(),
                  error: (e, _) => _ErrorCard(message: e.toString()),
                );
              },
              loading: () => const Padding(
                padding: EdgeInsets.all(16),
                child: Center(child: CircularProgressIndicator()),
              ),
              error: (e, _) => _ErrorCard(message: e.toString()),
            ),
          ],
        ),
      ),
    );
  }
}

class _NextShiftCard extends StatelessWidget {
  const _NextShiftCard({required this.shift, required this.workplaces});
  final Shift? shift;
  final List<Workplace> workplaces;

  @override
  Widget build(BuildContext context) {
    if (shift == null) {
      return const _EmptyCard();
    }
    final w = workplaces.firstWhere((x) => x.id == shift!.workplaceId);
    final now = DateTime.now();
    final diff = shift!.start.difference(now);
    final inText = diff.isNegative ? 'Ahora' : 'En ${fmtDurationShort(diff)}';

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _WorkChip(alias: w.alias, color: w.color),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    '${w.name}',
                    style: Theme.of(context).textTheme.titleMedium,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.secondaryContainer,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(inText, style: Theme.of(context).textTheme.labelLarge),
                )
              ],
            ),
            const SizedBox(height: 12),
            Text(
              _titleForShift(w, shift!),
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            Text(
              fmtRangeWithDay(shift!.start, shift!.end),
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => context.push('/shift/${shift!.id}'),
                    icon: const Icon(Icons.visibility_outlined),
                    label: const Text('Ver detalle'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: () => context.push('/shift/${shift!.id}/edit'),
                    icon: const Icon(Icons.edit_outlined),
                    label: const Text('Editar'),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  static String _titleForShift(Workplace w, Shift s) {
    final range = fmtRange(s.start, s.end);
    final night = s.type == ShiftType.h12Night ? '🌙 ' : '';
    final type = s.type == ShiftType.h24 ? '24h' : (s.type == ShiftType.custom ? '' : '12h');
    if (s.type == ShiftType.custom && w.alias == 'EMER') {
      return '🚑 EMERGENCIA $range';
    }
    return '$night${w.alias} $type $range'.trim();
  }
}

class _UpcomingTile extends StatelessWidget {
  const _UpcomingTile({required this.shift, required this.workplaces});
  final Shift shift;
  final List<Workplace> workplaces;

  @override
  Widget build(BuildContext context) {
    final w = workplaces.firstWhere((x) => x.id == shift.workplaceId);
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      leading: _WorkChip(alias: w.alias, color: w.color),
      title: Text(_title(w, shift)),
      subtitle: Text(fmtRangeWithDay(shift.start, shift.end)),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => context.push('/shift/${shift.id}'),
    );
  }

  String _title(Workplace w, Shift s) {
    final range = fmtRange(s.start, s.end);
    final night = s.type == ShiftType.h12Night ? '🌙 ' : '';
    if (s.type == ShiftType.custom && w.alias == 'EMER') return '🚑 EMERGENCIA $range';
    if (s.type == ShiftType.h24) return '${w.alias} 24h $range';
    if (s.type == ShiftType.h12Day) return '${w.alias} 12h $range';
    if (s.type == ShiftType.h12Night) return '$night${w.alias} 12h $range';
    return '${w.alias} $range';
  }
}

class _WorkChip extends StatelessWidget {
  const _WorkChip({required this.alias, required this.color});
  final String alias;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(color: color.withOpacity(0.18), borderRadius: BorderRadius.circular(14)),
      alignment: Alignment.center,
      child: Text(
        alias,
        style: Theme.of(context).textTheme.labelLarge?.copyWith(
          fontWeight: FontWeight.w800,
          color: color,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}

class _EmptyCard extends StatelessWidget {
  const _EmptyCard();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Próxima guardia', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Text('No hay guardias próximas', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            const Text('Agregá una guardia para verla acá y recibir recordatorios.'),
          ],
        ),
      ),
    );
  }
}

class _SkeletonCard extends StatelessWidget {
  const _SkeletonCard();
  @override
  Widget build(BuildContext context) => const Card(child: SizedBox(height: 160));
}

class _ErrorCard extends StatelessWidget {
  const _ErrorCard({required this.message});
  final String message;
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Text('Error: $message'),
    ),
  );
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.text});
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(16),
    child: Text(text),
  );
}
