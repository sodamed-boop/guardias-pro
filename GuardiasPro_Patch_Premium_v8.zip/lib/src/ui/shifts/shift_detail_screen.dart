import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../data/db.dart';
import '../../data/models.dart';
import '../../data/providers.dart';
import '../../services/notifications.dart';
import '../../services/widget_sync.dart';
import '../../utils/datetime.dart';

class ShiftDetailScreen extends ConsumerWidget {
  const ShiftDetailScreen({super.key, required this.shiftId});
  final int shiftId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.read(appDbProvider);

    return FutureBuilder<Shift?>(
      future: db.getShiftById(shiftId),
      builder: (context, snap) {
        if (!snap.hasData) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Scaffold(body: Center(child: CircularProgressIndicator()));
          }
          return Scaffold(appBar: AppBar(title: const Text('Guardia')), body: const Center(child: Text('No encontrada')));
        }

        final shift = snap.data!;
        return ref.watch(workplacesProvider).when(
          data: (workplaces) {
            final w = workplaces.firstWhere((x) => x.id == shift.workplaceId);
            return Scaffold(
              appBar: AppBar(
                title: const Text('Detalle'),
                actions: [
                  IconButton(
                    tooltip: 'Editar',
                    onPressed: () => context.push('/shift/$shiftId/edit'),
                    icon: const Icon(Icons.edit_outlined),
                  ),
                  IconButton(
                    tooltip: 'Eliminar',
                    onPressed: () => _delete(context, ref, shift),
                    icon: const Icon(Icons.delete_outline),
                  ),
                ],
              ),
              body: ListView(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
                children: [
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              _Badge(alias: w.alias, color: w.color),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(w.name, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Text(_title(w, shift),
                              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                          const SizedBox(height: 6),
                          Text(fmtRangeWithDay(shift.start, shift.end)),
                          const SizedBox(height: 10),
                          Text('Duración: ${fmtDurationShort(shift.duration)}'),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Alertas', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                          const SizedBox(height: 8),
                          if (shift.alertMinutesBefore.isEmpty)
                            const Text('Sin alertas configuradas.')
                          else
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                for (final m in shift.alertMinutesBefore)
                                  Chip(label: Text(_fmt(m))),
                              ],
                            ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  if ((w.address ?? '').isNotEmpty)
                    Card(
                      child: ListTile(
                        title: const Text('Abrir ubicación'),
                        subtitle: Text(w.address!),
                        trailing: const Icon(Icons.open_in_new),
                        onTap: () {
                          // v2: open maps intent
                          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Maps se agrega en v1.1')));
                        },
                      ),
                    ),
                ],
              ),
            );
          },
          loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
          error: (e, _) => Scaffold(appBar: AppBar(title: const Text('Guardia')), body: Padding(padding: const EdgeInsets.all(16), child: Text('Error: $e'))),
        );
      },
    );
  }

  static String _title(Workplace w, Shift s) {
    final range = fmtRange(s.start, s.end);
    if (w.alias == 'EMER' && s.type == ShiftType.custom) return '🚑 EMERGENCIA $range';
    if (s.type == ShiftType.h24) return '${w.alias} 24h $range';
    if (s.type == ShiftType.h12Day) return '${w.alias} 12h $range';
    if (s.type == ShiftType.h12Night) return '${w.alias} 🌙 12h $range';
    return '${w.alias} $range';
  }

  static String _fmt(int minutes) {
    final h = minutes ~/ 60;
    final m = minutes % 60;
    if (m == 0) return '${h}h antes';
    if (h == 0) return '${m}m antes';
    return '${h}h ${m}m antes';
  }

  static Future<void> _delete(BuildContext context, WidgetRef ref, Shift shift) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Eliminar guardia'),
        content: const Text('¿Seguro? Se borrará y se cancelarán sus alertas.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Eliminar')),
        ],
      ),
    );
    if (ok != true) return;

    final db = ref.read(appDbProvider);
    await db.deleteShift(shift.id);

    final notif = ref.read(notificationsServiceProvider);
    await notif.cancelForShift(shift.id);

    ref.invalidate(upcomingShiftsProvider);
    ref.invalidate(nextShiftProvider);

    if (context.mounted) {
      context.pop();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Guardia eliminada')));
    }
  }
}

class _Badge extends StatelessWidget {
  const _Badge({required this.alias, required this.color});
  final String alias;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 44,
      height: 44,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: color.withOpacity(0.18),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(alias, style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w900, color: color)),
    );
  }
}
