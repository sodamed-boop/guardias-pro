import 'dart:convert';
import 'package:flutter/material.dart';

enum ShiftType {
  h24,
  h12Day,
  h12Night,
  custom,
}

String shiftTypeLabel(ShiftType t) {
  switch (t) {
    case ShiftType.h24:
      return '24h';
    case ShiftType.h12Day:
      return '12h Día';
    case ShiftType.h12Night:
      return '12h Noche';
    case ShiftType.custom:
      return 'Personalizada';
  }
}

class Workplace {
  final int id;
  final String name;
  final String alias;
  final int colorValue; // ARGB int
  final String? address;
  final String? notes;

  const Workplace({
    required this.id,
    required this.name,
    required this.alias,
    required this.colorValue,
    this.address,
    this.notes,
  });

  Color get color => Color(colorValue);

  Workplace copyWith({
    int? id,
    String? name,
    String? alias,
    int? colorValue,
    String? address,
    String? notes,
  }) {
    return Workplace(
      id: id ?? this.id,
      name: name ?? this.name,
      alias: alias ?? this.alias,
      colorValue: colorValue ?? this.colorValue,
      address: address ?? this.address,
      notes: notes ?? this.notes,
    );
  }
}

class Shift {
  final int id;
  final int workplaceId;
  final ShiftType type;
  final DateTime start;
  final DateTime end;
  final String? notes;
  final List<int> alertMinutesBefore; // e.g. [1440, 180]

  const Shift({
    required this.id,
    required this.workplaceId,
    required this.type,
    required this.start,
    required this.end,
    required this.alertMinutesBefore,
    this.notes,
  });

  Duration get duration => end.difference(start);

  Shift copyWith({
    int? id,
    int? workplaceId,
    ShiftType? type,
    DateTime? start,
    DateTime? end,
    String? notes,
    List<int>? alertMinutesBefore,
  }) {
    return Shift(
      id: id ?? this.id,
      workplaceId: workplaceId ?? this.workplaceId,
      type: type ?? this.type,
      start: start ?? this.start,
      end: end ?? this.end,
      notes: notes ?? this.notes,
      alertMinutesBefore: alertMinutesBefore ?? this.alertMinutesBefore,
    );
  }

  static String alertsToJson(List<int> minutes) => jsonEncode(minutes);
  static List<int> alertsFromJson(String raw) {
    try {
      final v = jsonDecode(raw);
      if (v is List) return v.map((e) => (e as num).toInt()).toList();
    } catch (_) {}
    return const [];
  }
}

class ShiftTemplate {
  final int id;
  final String title;
  final int workplaceId;
  final ShiftType type;
  final int startMinutes; // minutes from 00:00
  final int endMinutes;   // minutes from 00:00 (can be less than start => next day)
  final List<int> alertMinutesBefore;

  const ShiftTemplate({
    required this.id,
    required this.title,
    required this.workplaceId,
    required this.type,
    required this.startMinutes,
    required this.endMinutes,
    required this.alertMinutesBefore,
  });
}
