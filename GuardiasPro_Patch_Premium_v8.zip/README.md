# Guardias Pro — Patch (Flutter / Android)

Este ZIP NO es un APK. Es un “proyecto listo” (código + archivos) para que puedas generar el APK en tu PC (o con build en la nube).
Motivo: para compilar un APK se necesita el Android SDK + Flutter, que no están disponibles en este entorno.

## Opción A (recomendada): generar tu APK en tu PC (Windows/Mac/Linux)

### 1) Instalá herramientas (una sola vez)
1. Instalá **Flutter (stable)**.
2. Instalá **Android Studio** (incluye Android SDK).
3. En Android Studio: SDK Manager → instalá:
   - Android SDK Platform (última estable)
   - Android SDK Build-Tools
   - Android SDK Command-line Tools
4. Abrí una terminal y ejecutá:
   - `flutter doctor`
   - Seguí lo que te pida hasta que todo quede en verde.

### 2) Creá el proyecto base
En una carpeta nueva, ejecutá:
- `flutter create guardias_pro`
- Entrá: `cd guardias_pro`

### 3) Copiá este patch encima del proyecto
1. Descomprimí este ZIP.
2. Copiá TODO su contenido dentro de la carpeta `guardias_pro/` y aceptá “reemplazar archivos” cuando lo pida:
   - `lib/`
   - `assets/`
   - `android/` (solo las subcarpetas indicadas en este patch)
   - archivos de configuración (`pubspec.yaml` tiene instrucciones)

### 4) Actualizá dependencias
En la terminal dentro de `guardias_pro/`:
- `flutter pub get`

### 5) Generá el APK (release)
- `flutter build apk --release`

El APK final queda en:
- `build/app/outputs/flutter-apk/app-release.apk`

### 6) Instalalo en tu teléfono
- Copiá el APK al teléfono y abrilo, o:
- Con USB + depuración:
  - `adb install -r build/app/outputs/flutter-apk/app-release.apk`

---

## Opción B: build en la nube (sin instalar Android SDK)
Si querés evitar instalar todo, podés usar un servicio de CI (por ejemplo Codemagic o GitHub Actions) para compilar el APK.
Pasos típicos:
1) Subís el proyecto a GitHub.
2) Conectás el repo al servicio de build.
3) Ejecutás `flutter build apk --release`.
4) Descargás el APK resultante.

---

## Qué incluye esta app (MVP premium)
- 3 trabajos preconfigurados: LH, HSIDH, EMER
- Tipos: 24h / 12h Día / 12h Noche / Personalizada
- Calendario mensual en **bloques** (máximo 3 por día + “+N”)
- Agenda (lista) y Dashboard “Próxima guardia”
- Plantillas (1 toque) y duplicar
- Detección de conflictos (solapamientos)
- Notificaciones por tipo (defaults):
  - LH 24h: 24h antes + 3h antes
  - HSIDH día: 12h antes + 2h antes
  - HSIDH noche: 12h antes + 1h antes
  - EMER: 2h antes + 30 min antes
- Widget Android: “Próxima guardia” (usa HomeWidget)

---

## Notas importantes (Android 13+)
- La app solicita permiso de notificaciones.
- Para que avise puntual, puede ser necesario permitir “alarmas exactas” según dispositivo/ROM.
- En “Ajustes” hay una sección de ayuda para batería/notificaciones.

---

## Archivos de configuración a revisar
- `pubspec.yaml` (copiar el bloque de dependencias)
- `android/app/src/main/AndroidManifest.xml` (ya incluye receiver del widget)
- `android/app/src/main/kotlin/.../NextShiftWidgetProvider.kt`
- `android/app/src/main/res/layout/widget_next_shift.xml`

¡Listo!


## Nota
Este patch usa `CardThemeData` (cambio reciente en Flutter por normalización de temas de componentes).
