import 'dart:convert';
import 'package:flutter/material.dart';
import 'db.dart';
import 'models.dart';

const _seedKey = 'seeded_v1';

class DefaultConfig {
  static const int colorLH = 0xFF1565C0;      // azul
  static const int colorHSIDH = 0xFF2E7D32;   // verde
  static const int colorEMER = 0xFFC62828;    // rojo

  static List<int> alertsLH24 = const [1440, 180];
  static List<int> alertsHSIDHDay = const [720, 120];
  static List<int> alertsHSIDHNight = const [720, 60];
  static List<int> alertsEmer = const [120, 30];
}

Future<void> seedIfNeeded(AppDb db) async {
  final already = await db.getKv(_seedKey);
  if (already == 'true') return;

  // Workplaces
  final idLH = await db.insertWorkplace(
    name: 'Hospital Gral Las Heras',
    alias: 'LH',
    colorValue: DefaultConfig.colorLH,
    address: null,
    notes: 'Guardias 24h 08:00–08:00',
  );

  final idHS = await db.insertWorkplace(
    name: 'Hospital Santa Isabel de Hungría',
    alias: 'HSIDH',
    colorValue: DefaultConfig.colorHSIDH,
    address: null,
    notes: 'Día 08:00–20:00 · Noche 20:00–08:00',
  );

  final idEM = await db.insertWorkplace(
    name: 'Servicio de Emergencia',
    alias: 'EMER',
    colorValue: DefaultConfig.colorEMER,
    address: null,
    notes: 'Turnos variables',
  );

  // Templates
  await db.insertTemplate(
    title: '🩺 LH 24h (08–08)',
    workplaceId: idLH,
    type: ShiftType.h24,
    startMinutes: 8 * 60,
    endMinutes: 8 * 60, // next day
    alertMinutesBefore: DefaultConfig.alertsLH24,
  );

  await db.insertTemplate(
    title: '🩺 HSIDH 12h (08–20)',
    workplaceId: idHS,
    type: ShiftType.h12Day,
    startMinutes: 8 * 60,
    endMinutes: 20 * 60,
    alertMinutesBefore: DefaultConfig.alertsHSIDHDay,
  );

  await db.insertTemplate(
    title: '🌙 HSIDH NOCHE (20–08)',
    workplaceId: idHS,
    type: ShiftType.h12Night,
    startMinutes: 20 * 60,
    endMinutes: 8 * 60, // next day
    alertMinutesBefore: DefaultConfig.alertsHSIDHNight,
  );

  await db.insertTemplate(
    title: '🚑 EMERGENCIA (variable)',
    workplaceId: idEM,
    type: ShiftType.custom,
    startMinutes: 9 * 60,
    endMinutes: 12 * 60,
    alertMinutesBefore: DefaultConfig.alertsEmer,
  );

  // Default alert settings (stored as JSON)
  final defaults = {
    'h24': DefaultConfig.alertsLH24,
    'h12Day': DefaultConfig.alertsHSIDHDay,
    'h12Night': DefaultConfig.alertsHSIDHNight,
    'custom': DefaultConfig.alertsEmer,
  };
  await db.putKv('alert_defaults', jsonEncode(defaults));

  await db.putKv(_seedKey, 'true');
}
