import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

import 'models.dart';

final appDbProvider = Provider<AppDb>((ref) => AppDb());

class AppDb {
  static const _dbName = 'guardias_pro.db';
  static const _dbVersion = 1;

  Database? _db;

  Future<void> init() async {
    if (_db != null) return;
    final dir = await getApplicationDocumentsDirectory();
    final path = p.join(dir.path, _dbName);
    _db = await openDatabase(
      path,
      version: _dbVersion,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE workplaces (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            alias TEXT NOT NULL,
            colorValue INTEGER NOT NULL,
            address TEXT,
            notes TEXT
          );
        ''');

        await db.execute('''
          CREATE TABLE shifts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            workplaceId INTEGER NOT NULL,
            type INTEGER NOT NULL,
            startMillis INTEGER NOT NULL,
            endMillis INTEGER NOT NULL,
            alertsJson TEXT NOT NULL,
            notes TEXT,
            createdAtMillis INTEGER NOT NULL,
            FOREIGN KEY(workplaceId) REFERENCES workplaces(id) ON DELETE CASCADE
          );
        ''');

        await db.execute('''
          CREATE TABLE templates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            workplaceId INTEGER NOT NULL,
            type INTEGER NOT NULL,
            startMinutes INTEGER NOT NULL,
            endMinutes INTEGER NOT NULL,
            alertsJson TEXT NOT NULL,
            FOREIGN KEY(workplaceId) REFERENCES workplaces(id) ON DELETE CASCADE
          );
        ''');

        await db.execute('''
          CREATE TABLE kv (
            k TEXT PRIMARY KEY,
            v TEXT NOT NULL
          );
        ''');

        await db.execute('CREATE INDEX idx_shifts_start ON shifts(startMillis);');
        await db.execute('CREATE INDEX idx_shifts_workplace ON shifts(workplaceId);');
      },
    );
  }

  Database get _database {
    final db = _db;
    if (db == null) {
      throw StateError('DB not initialized. Call init() first.');
    }
    return db;
  }

  Future<int> insertWorkplace({
    required String name,
    required String alias,
    required int colorValue,
    String? address,
    String? notes,
  }) async {
    return _database.insert('workplaces', {
      'name': name,
      'alias': alias,
      'colorValue': colorValue,
      'address': address,
      'notes': notes,
    });
  }

  Future<List<Workplace>> getWorkplaces() async {
    final rows = await _database.query('workplaces', orderBy: 'id ASC');
    return rows.map((r) => Workplace(
      id: r['id'] as int,
      name: r['name'] as String,
      alias: r['alias'] as String,
      colorValue: r['colorValue'] as int,
      address: r['address'] as String?,
      notes: r['notes'] as String?,
    )).toList();
  }

  Future<Workplace?> getWorkplaceById(int id) async {
    final rows = await _database.query('workplaces', where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    final r = rows.first;
    return Workplace(
      id: r['id'] as int,
      name: r['name'] as String,
      alias: r['alias'] as String,
      colorValue: r['colorValue'] as int,
      address: r['address'] as String?,
      notes: r['notes'] as String?,
    );
  }

  Future<int> upsertShift({
    int? id,
    required int workplaceId,
    required ShiftType type,
    required DateTime start,
    required DateTime end,
    required List<int> alertMinutesBefore,
    String? notes,
  }) async {
    final payload = {
      'workplaceId': workplaceId,
      'type': type.index,
      'startMillis': start.millisecondsSinceEpoch,
      'endMillis': end.millisecondsSinceEpoch,
      'alertsJson': Shift.alertsToJson(alertMinutesBefore),
      'notes': notes,
      'createdAtMillis': DateTime.now().millisecondsSinceEpoch,
    };

    if (id == null) {
      return _database.insert('shifts', payload);
    } else {
      await _database.update('shifts', payload, where: 'id = ?', whereArgs: [id]);
      return id;
    }
  }

  Future<void> deleteShift(int id) async {
    await _database.delete('shifts', where: 'id = ?', whereArgs: [id]);
  }

  Future<Shift?> getShiftById(int id) async {
    final rows = await _database.query('shifts', where: 'id = ?', whereArgs: [id], limit: 1);
    if (rows.isEmpty) return null;
    return _shiftFromRow(rows.first);
  }

  Shift _shiftFromRow(Map<String, Object?> r) {
    return Shift(
      id: r['id'] as int,
      workplaceId: r['workplaceId'] as int,
      type: ShiftType.values[r['type'] as int],
      start: DateTime.fromMillisecondsSinceEpoch(r['startMillis'] as int),
      end: DateTime.fromMillisecondsSinceEpoch(r['endMillis'] as int),
      alertMinutesBefore: Shift.alertsFromJson(r['alertsJson'] as String),
      notes: r['notes'] as String?,
    );
  }

  Future<List<Shift>> getShiftsBetween(DateTime startInclusive, DateTime endExclusive) async {
    final rows = await _database.query(
      'shifts',
      where: 'startMillis >= ? AND startMillis < ?',
      whereArgs: [startInclusive.millisecondsSinceEpoch, endExclusive.millisecondsSinceEpoch],
      orderBy: 'startMillis ASC',
    );
    return rows.map(_shiftFromRow).toList();
  }

  Future<List<Shift>> getUpcomingShifts(DateTime now, {int limit = 200}) async {
    final rows = await _database.query(
      'shifts',
      where: 'startMillis >= ?',
      whereArgs: [now.millisecondsSinceEpoch],
      orderBy: 'startMillis ASC',
      limit: limit,
    );
    return rows.map(_shiftFromRow).toList();
  }

  Future<List<Shift>> getAllShifts({int limit = 2000}) async {
    final rows = await _database.query('shifts', orderBy: 'startMillis DESC', limit: limit);
    return rows.map(_shiftFromRow).toList();
  }

  Future<List<Shift>> getShiftsOverlapping(DateTime start, DateTime end, {int? excludeShiftId}) async {
    // overlap if: existing.start < end && existing.end > start
    final where = StringBuffer('startMillis < ? AND endMillis > ?');
    final args = <Object?>[end.millisecondsSinceEpoch, start.millisecondsSinceEpoch];
    if (excludeShiftId != null) {
      where.write(' AND id <> ?');
      args.add(excludeShiftId);
    }
    final rows = await _database.query('shifts', where: where.toString(), whereArgs: args, orderBy: 'startMillis ASC');
    return rows.map(_shiftFromRow).toList();
  }

  Future<int> insertTemplate({
    required String title,
    required int workplaceId,
    required ShiftType type,
    required int startMinutes,
    required int endMinutes,
    required List<int> alertMinutesBefore,
  }) async {
    return _database.insert('templates', {
      'title': title,
      'workplaceId': workplaceId,
      'type': type.index,
      'startMinutes': startMinutes,
      'endMinutes': endMinutes,
      'alertsJson': Shift.alertsToJson(alertMinutesBefore),
    });
  }

  Future<List<ShiftTemplate>> getTemplates() async {
    final rows = await _database.query('templates', orderBy: 'id ASC');
    return rows.map((r) => ShiftTemplate(
      id: r['id'] as int,
      title: r['title'] as String,
      workplaceId: r['workplaceId'] as int,
      type: ShiftType.values[r['type'] as int],
      startMinutes: r['startMinutes'] as int,
      endMinutes: r['endMinutes'] as int,
      alertMinutesBefore: Shift.alertsFromJson(r['alertsJson'] as String),
    )).toList();
  }

  Future<void> deleteTemplate(int id) async {
    await _database.delete('templates', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> putKv(String k, String v) async {
    await _database.insert('kv', {'k': k, 'v': v}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<String?> getKv(String k) async {
    final rows = await _database.query('kv', where: 'k = ?', whereArgs: [k], limit: 1);
    if (rows.isEmpty) return null;
    return rows.first['v'] as String;
  }
}
