import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../data/db.dart';
import '../../data/models.dart';
import '../../data/providers.dart';
import '../../services/notifications.dart';
import '../../services/widget_sync.dart';
import '../../utils/datetime.dart';

class TemplatesScreen extends ConsumerWidget {
  const TemplatesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final templatesAsync = ref.watch(templatesProvider);
    final workplacesAsync = ref.watch(workplacesProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Plantillas'),
        actions: [
          IconButton(
            tooltip: 'Nueva guardia',
            onPressed: () => context.push('/shift/new'),
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: templatesAsync.when(
        data: (templates) => workplacesAsync.when(
          data: (workplaces) {
            if (templates.isEmpty) {
              return const Center(child: Text('No hay plantillas'));
            }
            return ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 20),
              itemCount: templates.length,
              itemBuilder: (context, i) {
                final t = templates[i];
                final w = workplaces.firstWhere((x) => x.id == t.workplaceId);
                final subtitle = '${w.name} · ${_timeRangeFromMinutes(t.startMinutes, t.endMinutes)} · alertas: ${t.alertMinutesBefore.join(", ")} min';
                return Card(
                  child: ListTile(
                    leading: _Badge(alias: w.alias, color: w.color),
                    title: Text(t.title, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
                    subtitle: Text(subtitle),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _useTemplate(context, ref, t, w),
                  ),
                );
              },
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (e, _) => Padding(padding: const EdgeInsets.all(16), child: Text('Error: $e')),
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Padding(padding: const EdgeInsets.all(16), child: Text('Error: $e')),
      ),
    );
  }

  static String _timeRangeFromMinutes(int startMin, int endMin) {
    String fmt(int m) => '${(m ~/ 60).toString().padLeft(2, '0')}:${(m % 60).toString().padLeft(2, '0')}';
    final s = fmt(startMin);
    final e = fmt(endMin);
    return '$s–$e';
  }

  static Future<void> _useTemplate(BuildContext context, WidgetRef ref, ShiftTemplate t, Workplace w) async {
    final date = DateTime.now();
    final start = DateTime(date.year, date.month, date.day).add(Duration(minutes: t.startMinutes));
    var endBase = DateTime(date.year, date.month, date.day).add(Duration(minutes: t.endMinutes));
    if (endBase.isBefore(start) || endBase.isAtSameMomentAs(start)) {
      endBase = endBase.add(const Duration(days: 1));
    }

    final db = ref.read(appDbProvider);
    final id = await db.upsertShift(
      workplaceId: t.workplaceId,
      type: t.type,
      start: start,
      end: endBase,
      alertMinutesBefore: t.alertMinutesBefore,
      notes: null,
    );

    // schedule notifications
    final notifications = ref.read(notificationsServiceProvider);
    await notifications.rescheduleForShift(
      Shift(id: id, workplaceId: t.workplaceId, type: t.type, start: start, end: endBase, alertMinutesBefore: t.alertMinutesBefore),
      w,
    );

    ref.invalidate(upcomingShiftsProvider);
    ref.invalidate(nextShiftProvider);

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Guardia creada desde plantilla (hoy). Editala si hace falta.')));
      context.push('/shift/$id/edit');
    }
  }
}

class _Badge extends StatelessWidget {
  const _Badge({required this.alias, required this.color});
  final String alias;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 44,
      height: 44,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: color.withOpacity(0.18),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(alias, style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w900, color: color)),
    );
  }
}
