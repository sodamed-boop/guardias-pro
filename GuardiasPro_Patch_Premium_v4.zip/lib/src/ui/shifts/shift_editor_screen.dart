import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../data/db.dart';
import '../../data/models.dart';
import '../../data/providers.dart';
import '../../services/notifications.dart';
import '../../services/widget_sync.dart';
import '../../utils/datetime.dart';

class ShiftEditorScreen extends ConsumerStatefulWidget {
  const ShiftEditorScreen({super.key, this.editShiftId, this.prefillDateIso, this.prefillWorkplaceId});

  final int? editShiftId;
  final String? prefillDateIso;
  final int? prefillWorkplaceId;

  @override
  ConsumerState<ShiftEditorScreen> createState() => _ShiftEditorScreenState();
}

class _ShiftEditorScreenState extends ConsumerState<ShiftEditorScreen> {
  int? _workplaceId;
  ShiftType _type = ShiftType.h24;
  DateTime _date = DateTime.now();
  TimeOfDay? _startTime;
  TimeOfDay? _endTime;
  final _notes = TextEditingController();
  List<int> _alerts = const [];

  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    // prefill date from query
    if (widget.prefillDateIso != null) {
      final parts = widget.prefillDateIso!.split('-').map(int.parse).toList();
      if (parts.length == 3) {
        _date = DateTime(parts[0], parts[1], parts[2]);
      }
    }
    if (widget.prefillWorkplaceId != null) _workplaceId = widget.prefillWorkplaceId;

    final db = ref.read(appDbProvider);

    if (widget.editShiftId != null) {
      final s = await db.getShiftById(widget.editShiftId!);
      if (s != null) {
        _workplaceId = s.workplaceId;
        _type = s.type;
        _date = DateTime(s.start.year, s.start.month, s.start.day);
        _startTime = TimeOfDay(hour: s.start.hour, minute: s.start.minute);
        _endTime = TimeOfDay(hour: s.end.hour, minute: s.end.minute);
        _alerts = List<int>.from(s.alertMinutesBefore);
        _notes.text = s.notes ?? '';
      }
    } else {
      // defaults from alertDefaultsProvider
      final defaults = await ref.read(alertDefaultsProvider.future);
      _alerts = List<int>.from(defaults[_type] ?? const [1440, 180]);
    }

    setState(() => _loading = false);
  }

  @override
  void dispose() {
    _notes.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final workplacesAsync = ref.watch(workplacesProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.editShiftId == null ? 'Nueva guardia' : 'Editar guardia'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : workplacesAsync.when(
              data: (workplaces) => _body(context, workplaces),
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => Padding(padding: const EdgeInsets.all(16), child: Text('Error: $e')),
            ),
    );
  }

  Widget _body(BuildContext context, List<Workplace> workplaces) {
    if (_workplaceId == null && workplaces.isNotEmpty) {
      _workplaceId = workplaces.first.id;
    }

    final w = workplaces.firstWhere((x) => x.id == _workplaceId);
    final scheme = Theme.of(context).colorScheme;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
      children: [
        Text('Trabajo', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: [
            for (final wp in workplaces)
              ChoiceChip(
                label: Text(wp.alias),
                selected: _workplaceId == wp.id,
                onSelected: (_) => setState(() {
                  _workplaceId = wp.id;
                  _applySuggestedTypeForWorkplace(wp);
                }),
              ),
          ],
        ),
        const SizedBox(height: 18),
        Text('Tipo', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        SegmentedButton<ShiftType>(
          segments: const [
            ButtonSegment(value: ShiftType.h24, label: Text('24h')),
            ButtonSegment(value: ShiftType.h12Day, label: Text('12 Día')),
            ButtonSegment(value: ShiftType.h12Night, label: Text('12 Noche')),
            ButtonSegment(value: ShiftType.custom, label: Text('Personalizada')),
          ],
          selected: {_type},
          onSelectionChanged: (s) async {
            final t = s.first;
            final defaults = await ref.read(alertDefaultsProvider.future);
            setState(() {
              _type = t;
              _alerts = List<int>.from(defaults[t] ?? _alerts);
              _startTime = null;
              _endTime = null;
            });
          },
        ),
        const SizedBox(height: 18),
        Text('Fecha', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        Card(
          child: ListTile(
            leading: const Icon(Icons.event_outlined),
            title: Text(fmtDateLong(_date), style: const TextStyle(fontWeight: FontWeight.w700)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              final picked = await showDatePicker(
                context: context,
                initialDate: _date,
                firstDate: DateTime(_date.year - 2),
                lastDate: DateTime(_date.year + 3),
              );
              if (picked != null) setState(() => _date = picked);
            },
          ),
        ),
        const SizedBox(height: 10),
        if (_type == ShiftType.custom)
          _CustomTimeCard(context)
        else
          _AutoTimeCard(w),
        const SizedBox(height: 18),
        Text('Notas', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        TextField(
          controller: _notes,
          maxLines: 3,
          decoration: const InputDecoration(hintText: 'Opcional (sector, detalles, etc.)'),
        ),
        const SizedBox(height: 18),
        Text('Alertas', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: _alerts.map((m) => Chip(label: Text(_fmt(m)))).toList(),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final out = await showDialog<List<int>>(context: context, builder: (_) => _EditAlertsDialog(initial: _alerts));
                          if (out != null) setState(() => _alerts = out);
                        },
                        icon: const Icon(Icons.edit_outlined),
                        label: const Text('Editar'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: TextButton(
                        onPressed: () async {
                          final defaults = await ref.read(alertDefaultsProvider.future);
                          setState(() => _alerts = List<int>.from(defaults[_type] ?? _alerts));
                        },
                        child: const Text('Restaurar defaults'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        FutureBuilder(
          future: _computeOverlapPreview(),
          builder: (context, snap) {
            if (!snap.hasData) return const SizedBox.shrink();
            final overlaps = snap.data as List<Shift>;
            if (overlaps.isEmpty) return const SizedBox.shrink();
            return Card(
              color: scheme.errorContainer,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Conflicto detectado', style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900)),
                    const SizedBox(height: 6),
                    for (final s in overlaps.take(3))
                      Text('• ${fmtRangeWithDay(s.start, s.end)}', style: Theme.of(context).textTheme.bodyMedium),
                    if (overlaps.length > 3) Text('… y ${overlaps.length - 3} más'),
                  ],
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: () => _save(context),
          icon: const Icon(Icons.check),
          label: const Text('Guardar'),
        ),
      ],
    );
  }

  Widget _AutoTimeCard(Workplace w) {
    final range = _suggestedRangeFor(w, _type);
    return Card(
      child: ListTile(
        leading: const Icon(Icons.schedule_outlined),
        title: Text(range, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: const Text('Horarios automáticos según tipo'),
      ),
    );
  }

  Widget _CustomTimeCard(BuildContext context) {
    return Card(
      child: Column(
        children: [
          ListTile(
            leading: const Icon(Icons.login_outlined),
            title: Text(_startTime == null ? 'Elegir inicio' : 'Inicio: ${_startTime!.format(context)}', style: const TextStyle(fontWeight: FontWeight.w700)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              final t = await showTimePicker(context: context, initialTime: _startTime ?? const TimeOfDay(hour: 8, minute: 0));
              if (t != null) setState(() => _startTime = t);
            },
          ),
          const Divider(height: 1),
          ListTile(
            leading: const Icon(Icons.logout_outlined),
            title: Text(_endTime == null ? 'Elegir fin' : 'Fin: ${_endTime!.format(context)}', style: const TextStyle(fontWeight: FontWeight.w700)),
            trailing: const Icon(Icons.chevron_right),
            onTap: () async {
              final t = await showTimePicker(context: context, initialTime: _endTime ?? const TimeOfDay(hour: 20, minute: 0));
              if (t != null) setState(() => _endTime = t);
            },
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 14),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text('Si el fin es menor que el inicio, se asume “día siguiente”.'),
            ),
          ),
        ],
      ),
    );
  }

  String _suggestedRangeFor(Workplace w, ShiftType t) {
    if (w.alias == 'LH' && t == ShiftType.h24) return '08:00–08:00 (día siguiente)';
    if (w.alias == 'HSIDH' && t == ShiftType.h12Day) return '08:00–20:00';
    if (w.alias == 'HSIDH' && t == ShiftType.h12Night) return '20:00–08:00 (día siguiente)';
    // fallback
    if (t == ShiftType.h24) return '08:00–08:00 (día siguiente)';
    if (t == ShiftType.h12Day) return '08:00–20:00';
    if (t == ShiftType.h12Night) return '20:00–08:00 (día siguiente)';
    return 'Personalizada';
  }

  void _applySuggestedTypeForWorkplace(Workplace w) {
    if (w.alias == 'LH') _type = ShiftType.h24;
    if (w.alias == 'EMER') _type = ShiftType.custom;
  }

  Future<List<Shift>> _computeOverlapPreview() async {
    final db = ref.read(appDbProvider);
    if (_workplaceId == null) return const [];
    final (start, end) = _computeStartEndPreview();
    return db.getShiftsOverlapping(start, end, excludeShiftId: widget.editShiftId);
  }

  (DateTime, DateTime) _computeStartEndPreview() {
    if (_workplaceId == null) return (_date, _date.add(const Duration(hours: 1)));
    final wAlias = _workplaceId;
    // Use workplace+type defaults, or custom selected times
    if (_type == ShiftType.custom) {
      final st = _startTime ?? const TimeOfDay(hour: 8, minute: 0);
      final en = _endTime ?? const TimeOfDay(hour: 9, minute: 0);
      final start = DateTime(_date.year, _date.month, _date.day, st.hour, st.minute);
      var end = DateTime(_date.year, _date.month, _date.day, en.hour, en.minute);
      if (!end.isAfter(start)) end = end.add(const Duration(days: 1));
      return (start, end);
    }

    // defaults by hospital (based on seeded aliases)
    // We'll derive from alias by reading workplaces in save(), but preview here uses type defaults.
    final start = DateTime(_date.year, _date.month, _date.day, _type == ShiftType.h12Night ? 20 : 8, 0);
    DateTime end;
    if (_type == ShiftType.h24) {
      end = start.add(const Duration(days: 1));
    } else if (_type == ShiftType.h12Day) {
      end = DateTime(_date.year, _date.month, _date.day, 20, 0);
    } else {
      end = DateTime(_date.year, _date.month, _date.day, 8, 0).add(const Duration(days: 1));
    }
    return (start, end);
  }

  String _fmt(int minutes) {
    final h = minutes ~/ 60;
    final m = minutes % 60;
    if (m == 0) return '${h}h antes';
    if (h == 0) return '${m}m antes';
    return '${h}h ${m}m antes';
  }

  Future<void> _save(BuildContext context) async {
    final workplaces = await ref.read(workplacesProvider.future);
    final wp = workplaces.firstWhere((x) => x.id == _workplaceId);

    final (start, end) = _computeStartEnd(wp);

    // conflicts
    final db = ref.read(appDbProvider);
    final overlaps = await db.getShiftsOverlapping(start, end, excludeShiftId: widget.editShiftId);
    if (overlaps.isNotEmpty) {
      final proceed = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Conflicto detectado'),
          content: const Text('Esta guardia se superpone con otra. ¿Querés guardar igual?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancelar')),
            FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Guardar igual')),
          ],
        ),
      );
      if (proceed != true) return;
    }

    final id = await db.upsertShift(
      id: widget.editShiftId,
      workplaceId: wp.id,
      type: _type,
      start: start,
      end: end,
      alertMinutesBefore: _alerts,
      notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
    );

    // notifications
    final notifications = ref.read(notificationsServiceProvider);
    final shift = Shift(
      id: id,
      workplaceId: wp.id,
      type: _type,
      start: start,
      end: end,
      alertMinutesBefore: _alerts,
      notes: _notes.text.trim().isEmpty ? null : _notes.text.trim(),
    );
    await notifications.rescheduleForShift(shift, wp);

    ref.invalidate(upcomingShiftsProvider);
    ref.invalidate(nextShiftProvider);

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Guardia guardada')));
      context.go('/home');
    }
  }

  (DateTime, DateTime) _computeStartEnd(Workplace wp) {
    if (_type == ShiftType.custom) {
      final st = _startTime ?? const TimeOfDay(hour: 8, minute: 0);
      final en = _endTime ?? const TimeOfDay(hour: 9, minute: 0);
      final start = DateTime(_date.year, _date.month, _date.day, st.hour, st.minute);
      var end = DateTime(_date.year, _date.month, _date.day, en.hour, en.minute);
      if (!end.isAfter(start)) end = end.add(const Duration(days: 1));
      return (start, end);
    }

    // Apply your real rules based on workplace alias:
    if (wp.alias == 'LH') {
      final start = DateTime(_date.year, _date.month, _date.day, 8, 0);
      final end = start.add(const Duration(days: 1));
      return (start, end);
    }
    if (wp.alias == 'HSIDH') {
      if (_type == ShiftType.h12Night) {
        final start = DateTime(_date.year, _date.month, _date.day, 20, 0);
        final end = DateTime(_date.year, _date.month, _date.day, 8, 0).add(const Duration(days: 1));
        return (start, end);
      } else {
        final start = DateTime(_date.year, _date.month, _date.day, 8, 0);
        final end = DateTime(_date.year, _date.month, _date.day, 20, 0);
        return (start, end);
      }
    }

    // EMER or fallback:
    if (_type == ShiftType.h24) {
      final start = DateTime(_date.year, _date.month, _date.day, 8, 0);
      final end = start.add(const Duration(days: 1));
      return (start, end);
    }
    if (_type == ShiftType.h12Night) {
      final start = DateTime(_date.year, _date.month, _date.day, 20, 0);
      final end = DateTime(_date.year, _date.month, _date.day, 8, 0).add(const Duration(days: 1));
      return (start, end);
    }
    if (_type == ShiftType.h12Day) {
      final start = DateTime(_date.year, _date.month, _date.day, 8, 0);
      final end = DateTime(_date.year, _date.month, _date.day, 20, 0);
      return (start, end);
    }
    final start = DateTime(_date.year, _date.month, _date.day, 9, 0);
    final end = DateTime(_date.year, _date.month, _date.day, 12, 0);
    return (start, end);
  }
}

class _EditAlertsDialog extends StatefulWidget {
  const _EditAlertsDialog({required this.initial});
  final List<int> initial;

  @override
  State<_EditAlertsDialog> createState() => _EditAlertsDialogState();
}

class _EditAlertsDialogState extends State<_EditAlertsDialog> {
  late final TextEditingController _c;

  @override
  void initState() {
    super.initState();
    _c = TextEditingController(text: widget.initial.join(','));
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Editar alertas'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _c,
            decoration: const InputDecoration(hintText: 'Ej: 1440,180'),
          ),
          const SizedBox(height: 10),
          const Text('Minutos antes separados por coma.'),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
        FilledButton(
          onPressed: () {
            final out = _c.text
                .split(',')
                .map((s) => s.trim())
                .where((s) => s.isNotEmpty)
                .map((s) => int.tryParse(s) ?? 0)
                .where((v) => v > 0)
                .toList();
            Navigator.pop(context, out);
          },
          child: const Text('Guardar'),
        ),
      ],
    );
  }
}
