import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:timezone/data/latest_all.dart' as tz;

import 'data/db.dart';
import 'data/seed.dart';
import 'services/notifications.dart';

Future<void> bootstrap(ProviderContainer container) async {
  tz.initializeTimeZones();

  final db = container.read(appDbProvider);
  await db.init();
  await seedIfNeeded(db);

  final notifications = container.read(notificationsServiceProvider);
  await notifications.init();
}
