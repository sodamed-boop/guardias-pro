# Android widget patch (HomeWidget)

Después de copiar el patch al proyecto, verificá:

1) `android/app/src/main/kotlin/<tu-paquete>/NextShiftWidgetProvider.kt`
   - Si tu paquete Kotlin es distinto, mové el archivo a la ruta correcta.
   - El paquete debe coincidir con tu `applicationId`.

2) `android/app/src/main/res/layout/widget_next_shift.xml`
3) `android/app/src/main/res/xml/next_shift_widget_info.xml`

4) En `AndroidManifest.xml` dentro de `<application>` agregar el receiver (si no quedó copiado):
   <receiver android:name=".NextShiftWidgetProvider" android:exported="false">
     <intent-filter>
       <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
     </intent-filter>
     <meta-data android:name="android.appwidget.provider" android:resource="@xml/next_shift_widget_info" />
   </receiver>

HomeWidget guarda datos en SharedPreferences y este widget los lee para mostrar “Próxima guardia”.
