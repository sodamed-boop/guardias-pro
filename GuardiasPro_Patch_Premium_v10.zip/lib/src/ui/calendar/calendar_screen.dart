import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../data/db.dart';
import '../../data/models.dart';
import '../../data/providers.dart';
import '../../utils/datetime.dart';

class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month, 1);
  bool _agenda = false;

  @override
  Widget build(BuildContext context) {
    final workplacesAsync = ref.watch(workplacesProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(_agenda ? 'Agenda' : 'Calendario'),
        actions: [
          IconButton(
            tooltip: 'Nueva guardia',
            onPressed: () => context.push('/shift/new'),
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: workplacesAsync.when(
        data: (workplaces) => _agenda
            ? _AgendaView(workplaces: workplaces)
            : _MonthView(
                month: _month,
                workplaces: workplaces,
                onPrev: () => setState(() => _month = DateTime(_month.year, _month.month - 1, 1)),
                onNext: () => setState(() => _month = DateTime(_month.year, _month.month + 1, 1)),
              ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Padding(padding: const EdgeInsets.all(16), child: Text('Error: $e')),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
          child: Row(
            children: [
              Expanded(
                child: SegmentedButton<bool>(
                  segments: const [
                    ButtonSegment(value: false, label: Text('Mes'), icon: Icon(Icons.calendar_month)),
                    ButtonSegment(value: true, label: Text('Agenda'), icon: Icon(Icons.view_agenda)),
                  ],
                  selected: {_agenda},
                  onSelectionChanged: (s) => setState(() => _agenda = s.first),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MonthView extends ConsumerWidget {
  const _MonthView({
    required this.month,
    required this.workplaces,
    required this.onPrev,
    required this.onNext,
  });

  final DateTime month;
  final List<Workplace> workplaces;
  final VoidCallback onPrev;
  final VoidCallback onNext;

  DateTime _startOfGrid(DateTime m) {
    final first = DateTime(m.year, m.month, 1);
    // Monday = 1 ... Sunday = 7
    final weekday = first.weekday;
    final delta = weekday - DateTime.monday; // 0 if monday
    return first.subtract(Duration(days: delta));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.read(appDbProvider);
    final startGrid = _startOfGrid(month);
    final endGrid = startGrid.add(const Duration(days: 42)); // 6 weeks
final monthTitle = '${_monthName(month.month)} ${month.year}';

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
          child: Row(
            children: [
              IconButton(onPressed: onPrev, icon: const Icon(Icons.chevron_left)),
              Expanded(
                child: Text(
                  monthTitle,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700),
                ),
              ),
              IconButton(onPressed: onNext, icon: const Icon(Icons.chevron_right)),
            ],
          ),
        ),
        const _WeekHeader(),
        Expanded(
          child: FutureBuilder<List<Shift>>(
              future: db.getShiftsBetween(startGrid, endGrid),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text('Error: ${snapshot.error}'),
                  );
                }
                final shifts = snapshot.data ?? const <Shift>[];
                return _MonthGrid(
                  month: month,
                  startGrid: startGrid,
                  shifts: shifts,
                  workplaces: workplaces,
                );
              },
            ),
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => Padding(padding: const EdgeInsets.all(16), child: Text('Error: $e')),
              ),
        ),
      ],
    );
  }

  String _monthName(int m) {
    const names = [
      'Enero','Febrero','Marzo','Abril','Mayo','Junio',
      'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'
    ];
    return names[m - 1];
  }
}

class _WeekHeader extends StatelessWidget {
  const _WeekHeader();

  @override
  Widget build(BuildContext context) {
    const days = ['LUN', 'MAR', 'MIÉ', 'JUE', 'VIE', 'SÁB', 'DOM'];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(
        children: [
          for (final d in days)
            Expanded(
              child: Center(
                child: Text(
                  d,
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w700),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _MonthGrid extends StatelessWidget {
  const _MonthGrid({
    required this.month,
    required this.startGrid,
    required this.shifts,
    required this.workplaces,
  });

  final DateTime month;
  final DateTime startGrid;
  final List<Shift> shifts;
  final List<Workplace> workplaces;

  @override
  Widget build(BuildContext context) {
    // Group shifts by start day (spec: show in start day only)
    final byDay = <DateTime, List<Shift>>{};
    for (final s in shifts) {
      final key = DateTime(s.start.year, s.start.month, s.start.day);
      byDay.putIfAbsent(key, () => []).add(s);
    }

    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 7,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        childAspectRatio: 0.82,
      ),
      itemCount: 42,
      itemBuilder: (context, index) {
        final day = startGrid.add(Duration(days: index));
        final isInMonth = day.month == month.month;
        final list = byDay[DateTime(day.year, day.month, day.day)] ?? const [];
        list.sort((a, b) => a.start.compareTo(b.start));
        return _DayCell(
          date: day,
          inMonth: isInMonth,
          shifts: list,
          workplaces: workplaces,
        );
      },
    );
  }
}

class _DayCell extends StatelessWidget {
  const _DayCell({
    required this.date,
    required this.inMonth,
    required this.shifts,
    required this.workplaces,
  });

  final DateTime date;
  final bool inMonth;
  final List<Shift> shifts;
  final List<Workplace> workplaces;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final bg = inMonth ? scheme.surfaceContainerLowest : scheme.surfaceContainerLow;
    final border = date == DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day)
        ? Border.all(color: scheme.primary, width: 1.6)
        : Border.all(color: scheme.outlineVariant.withOpacity(0.35), width: 1);

    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onLongPress: () {
        final iso = '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
        GoRouter.of(context).push('/shift/new?date=$iso');
      },
      child: Container(
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(14),
          border: border,
        ),
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${date.day}',
              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    fontWeight: FontWeight.w800,
                    color: inMonth ? scheme.onSurface : scheme.onSurface.withOpacity(0.45),
                  ),
            ),
            const SizedBox(height: 6),
            if (shifts.isEmpty)
              const Spacer()
            else
              ..._buildShiftBlocks(context),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildShiftBlocks(BuildContext context) {
    final maxVisible = 3;
    final visible = shifts.take(maxVisible).toList();
    final hidden = shifts.length - visible.length;

    final widgets = <Widget>[];
    for (final s in visible) {
      final w = workplaces.firstWhere((x) => x.id == s.workplaceId);
      widgets.add(_ShiftBlock(shift: s, workplace: w));
      widgets.add(const SizedBox(height: 4));
    }
    if (widgets.isNotEmpty) widgets.removeLast();

    if (hidden > 0) {
      widgets.add(const SizedBox(height: 6));
      widgets.add(_MoreChip(count: hidden, date: date, shifts: shifts, workplaces: workplaces));
    }
    return widgets;
  }
}

class _ShiftBlock extends StatelessWidget {
  const _ShiftBlock({required this.shift, required this.workplace});
  final Shift shift;
  final Workplace workplace;

  @override
  Widget build(BuildContext context) {
    final color = workplace.color;
    final scheme = Theme.of(context).colorScheme;
    final textColor = scheme.onSurface;

    final label = _label();
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () => GoRouter.of(context).push('/shift/${shift.id}'),
      child: Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.18),
          borderRadius: BorderRadius.circular(10),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 6),
        child: Text(
          label,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
                fontWeight: FontWeight.w800,
                height: 1.15,
                color: color.computeLuminance() < 0.35 ? scheme.onSurface : textColor,
              ),
        ),
      ),
    );
  }

  String _label() {
    final range = fmtRange(shift.start, shift.end);
    if (workplace.alias == 'EMER' && shift.type == ShiftType.custom) {
      return 'EMER $range';
    }
    if (shift.type == ShiftType.h24) return '${workplace.alias} 24h $range';
    if (shift.type == ShiftType.h12Night) return '${workplace.alias} 🌙 $range';
    if (shift.type == ShiftType.h12Day) return '${workplace.alias} $range';
    return '${workplace.alias} $range';
  }
}

class _MoreChip extends StatelessWidget {
  const _MoreChip({required this.count, required this.date, required this.shifts, required this.workplaces});
  final int count;
  final DateTime date;
  final List<Shift> shifts;
  final List<Workplace> workplaces;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: () => showModalBottomSheet(
        context: context,
        showDragHandle: true,
        builder: (_) => _DayEventsSheet(date: date, shifts: shifts, workplaces: workplaces),
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(999),
          color: Theme.of(context).colorScheme.secondaryContainer,
        ),
        child: Text('+$count', style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w800)),
      ),
    );
  }
}

class _DayEventsSheet extends StatelessWidget {
  const _DayEventsSheet({required this.date, required this.shifts, required this.workplaces});
  final DateTime date;
  final List<Shift> shifts;
  final List<Workplace> workplaces;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(fmtDateLong(date), style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            for (final s in shifts)
              ListTile(
                leading: _WorkBadge(w: workplaces.firstWhere((x) => x.id == s.workplaceId)),
                title: Text(_title(workplaces.firstWhere((x) => x.id == s.workplaceId), s)),
                subtitle: Text(fmtRangeWithDay(s.start, s.end)),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.of(context).pop();
                  GoRouter.of(context).push('/shift/${s.id}');
                },
              )
          ],
        ),
      ),
    );
  }

  String _title(Workplace w, Shift s) {
    final range = fmtRange(s.start, s.end);
    if (w.alias == 'EMER' && s.type == ShiftType.custom) return '🚑 EMERGENCIA $range';
    if (s.type == ShiftType.h24) return '${w.alias} 24h $range';
    if (s.type == ShiftType.h12Night) return '${w.alias} 🌙 $range';
    return '${w.alias} $range';
  }
}

class _WorkBadge extends StatelessWidget {
  const _WorkBadge({required this.w});
  final Workplace w;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 44,
      height: 44,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: w.color.withOpacity(0.18),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        w.alias,
        style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w900, color: w.color),
      ),
    );
  }
}

class _AgendaView extends ConsumerWidget {
  const _AgendaView({required this.workplaces});
  final List<Workplace> workplaces;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final upcomingAsync = ref.watch(upcomingShiftsProvider);

    return upcomingAsync.when(
      data: (list) {
        if (list.isEmpty) {
          return const Center(child: Text('No hay guardias próximas'));
        }
        // group by day
        final groups = <DateTime, List<Shift>>{};
        for (final s in list) {
          final k = DateTime(s.start.year, s.start.month, s.start.day);
          groups.putIfAbsent(k, () => []).add(s);
        }
        final keys = groups.keys.toList()..sort((a, b) => a.compareTo(b));
        return ListView(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 20),
          children: [
            for (final day in keys) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
                child: Text(fmtDateLong(day), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
              ),
              for (final s in groups[day]!) _AgendaTile(shift: s, workplace: workplaces.firstWhere((w) => w.id == s.workplaceId)),
            ]
          ],
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Padding(padding: const EdgeInsets.all(16), child: Text('Error: $e')),
    );
  }
}

class _AgendaTile extends StatelessWidget {
  const _AgendaTile({required this.shift, required this.workplace});
  final Shift shift;
  final Workplace workplace;

  @override
  Widget build(BuildContext context) {
    final title = (workplace.alias == 'EMER' && shift.type == ShiftType.custom)
        ? '🚑 EMERGENCIA ${fmtRange(shift.start, shift.end)}'
        : '${workplace.alias}${shift.type == ShiftType.h12Night ? " 🌙" : ""} ${fmtRange(shift.start, shift.end)}';

    return Card(
      margin: const EdgeInsets.fromLTRB(8, 6, 8, 6),
      child: ListTile(
        leading: Container(
          width: 10,
          height: double.infinity,
          decoration: BoxDecoration(
            color: workplace.color,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        title: Text(title, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
        subtitle: Text(workplace.name),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => GoRouter.of(context).push('/shift/${shift.id}'),
      ),
    );
  }
}
