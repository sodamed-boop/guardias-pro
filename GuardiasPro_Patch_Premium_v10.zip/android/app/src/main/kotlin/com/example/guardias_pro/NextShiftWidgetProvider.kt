package com.example.guardias_pro

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews
import androidx.core.graphics.ColorUtils

class NextShiftWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId)
        }
    }

    private fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
        val prefs = context.getSharedPreferences("HomeWidgetPreferences", Context.MODE_PRIVATE)
        val title = prefs.getString("next_title", "Sin guardias próximas") ?: "Sin guardias próximas"
        val subtitle = prefs.getString("next_subtitle", "Agregá una guardia") ?: "Agregá una guardia"
        val colorInt = prefs.getInt("next_color", 0xFF616161.toInt())

        val views = RemoteViews(context.packageName, R.layout.widget_next_shift)
        views.setTextViewText(R.id.w_title, title)
        views.setTextViewText(R.id.w_subtitle, subtitle)

        // tint card background lightly based on workplace color
        val bg = ColorUtils.setAlphaComponent(colorInt, 40)
        views.setInt(R.id.w_container, "setBackgroundColor", bg)
        views.setTextColor(R.id.w_title, Color.WHITE)
        views.setTextColor(R.id.w_subtitle, Color.WHITE)

        // Open app when tapped
        val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        views.setOnClickPendingIntent(R.id.w_container, pendingIntent)

        manager.updateAppWidget(widgetId, views)
    }
}
