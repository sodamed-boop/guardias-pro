import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;

import '../data/models.dart';
import '../data/db.dart';
import '../data/providers.dart';
import '../utils/datetime.dart';
import 'widget_sync.dart';

final notificationsServiceProvider = Provider<NotificationsService>((ref) {
  return NotificationsService(ref);
});

class NotificationsService {
  NotificationsService(this._ref);

  final Ref _ref;
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const init = InitializationSettings(android: android);
    await _plugin.initialize(init);

    // Android 13+ runtime permission
    await _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  Future<void> rescheduleForShift(Shift shift, Workplace workplace) async {
    await cancelForShift(shift.id);

    // schedule notifications for each minutes-before
    for (var i = 0; i < shift.alertMinutesBefore.length; i++) {
      final minutes = shift.alertMinutesBefore[i];
      final when = shift.start.subtract(Duration(minutes: minutes));
      if (when.isBefore(DateTime.now().subtract(const Duration(minutes: 1)))) continue;

      final id = _notifId(shift.id, i);
      final details = NotificationDetails(
        android: AndroidNotificationDetails(
          'guardias_alerts',
          'Alertas de guardias',
          channelDescription: 'Recordatorios de guardias médicas',
          importance: Importance.max,
          priority: Priority.high,
        ),
      );

      final title = 'Guardia: ${workplace.alias}';
      final body = '${shiftTitleCompact(workplace, shift)} · ${fmtRangeWithDay(shift.start, shift.end)}';

      await _plugin.zonedSchedule(
        id,
        title,
        body,
        tz.TZDateTime.from(when, tz.local),
        details,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: null,
      );
    }

    // Update widget with next shift (best effort)
    await WidgetSyncService.updateNextShiftWidget(
      nextShift: await _ref.read(nextShiftProvider.future),
      workplaces: await _ref.read(workplacesProvider.future),
    );
  }

  Future<void> cancelForShift(int shiftId) async {
    // cancel a reasonable range of possible alert ids
    for (var i = 0; i < 6; i++) {
      await _plugin.cancel(_notifId(shiftId, i));
    }
  }

  int _notifId(int shiftId, int idx) => shiftId * 10 + idx;

  static String shiftTitleCompact(Workplace w, Shift s) {
    final range = fmtRange(s.start, s.end);
    final night = s.type == ShiftType.h12Night ? ' 🌙' : '';
    final type = s.type == ShiftType.h24 ? '24h' : (s.type == ShiftType.custom ? 'EMER' : '12h');
    if (s.type == ShiftType.custom && w.alias == 'EMER') {
      return '${w.alias}$night $range';
    }
    return '${w.alias}$night $type $range';
  }
}
