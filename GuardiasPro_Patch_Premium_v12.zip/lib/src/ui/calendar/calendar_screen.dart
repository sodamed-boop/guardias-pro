import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../data/db.dart';
import '../../data/models.dart';
import '../../data/providers.dart';
import '../../utils/datetime.dart';

/// A slice of a shift that belongs to a single calendar day.
/// startMin/endMin are minutes since 00:00 of that day.
class _DaySlice {
  const _DaySlice({
    required this.shift,
    required this.workplace,
    required this.startMin,
    required this.endMin,
    required this.day,
  });

  final Shift shift;
  final Workplace workplace;
  final int startMin;
  final int endMin;
  final DateTime day;

  int get durationMin => (endMin - startMin).clamp(0, 24 * 60);
}

class CalendarScreen extends ConsumerStatefulWidget {
  const CalendarScreen({super.key});

  @override
  ConsumerState<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends ConsumerState<CalendarScreen> {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month, 1);
  bool _agenda = false;

  @override
  Widget build(BuildContext context) {
    final workplacesAsync = ref.watch(workplacesProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(_agenda ? 'Agenda' : 'Calendario'),
        actions: [
          IconButton(
            tooltip: 'Nueva guardia',
            onPressed: () => context.push('/shift/new'),
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: workplacesAsync.when(
        data: (workplaces) {
          if (_agenda) return _AgendaView(workplaces: workplaces);
          return _MonthView(
            month: _month,
            workplaces: workplaces,
            onPrev: () => setState(() => _month = DateTime(_month.year, _month.month - 1, 1)),
            onNext: () => setState(() => _month = DateTime(_month.year, _month.month + 1, 1)),
            onToday: () => setState(() => _month = DateTime(DateTime.now().year, DateTime.now().month, 1)),
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Padding(padding: const EdgeInsets.all(16), child: Text('Error: $e')),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
          child: SegmentedButton<bool>(
            segments: const [
              ButtonSegment(value: false, label: Text('Mes'), icon: Icon(Icons.calendar_month)),
              ButtonSegment(value: true, label: Text('Agenda'), icon: Icon(Icons.view_agenda)),
            ],
            selected: {_agenda},
            onSelectionChanged: (s) => setState(() => _agenda = s.first),
          ),
        ),
      ),
    );
  }
}

class _MonthView extends ConsumerWidget {
  const _MonthView({
    required this.month,
    required this.workplaces,
    required this.onPrev,
    required this.onNext,
    required this.onToday,
  });

  final DateTime month;
  final List<Workplace> workplaces;
  final VoidCallback onPrev;
  final VoidCallback onNext;
  final VoidCallback onToday;

  DateTime _startOfGrid(DateTime m) {
    final first = DateTime(m.year, m.month, 1);
    final weekday = first.weekday; // Monday=1
    final delta = weekday - DateTime.monday;
    return first.subtract(Duration(days: delta));
  }

  String _monthName(int m) {
    const names = [
      'Enero','Febrero','Marzo','Abril','Mayo','Junio',
      'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'
    ];
    return names[m - 1];
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final db = ref.read(appDbProvider);
    final startGrid = _startOfGrid(month);
    final endGrid = startGrid.add(const Duration(days: 42));
    final title = '${_monthName(month.month)} ${month.year}';

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
          child: Row(
            children: [
              IconButton(onPressed: onPrev, icon: const Icon(Icons.chevron_left)),
              Expanded(
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
                ),
              ),
              IconButton(onPressed: onNext, icon: const Icon(Icons.chevron_right)),
              IconButton(onPressed: onToday, icon: const Icon(Icons.today_outlined)),
            ],
          ),
        ),
        const _WeekHeader(),
        Expanded(
          child: FutureBuilder<List<Shift>>(
            future: db.getShiftsBetween(startGrid, endGrid),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }
              if (snapshot.hasError) {
                return Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text('Error: ${snapshot.error}'),
                );
              }
              final shifts = snapshot.data ?? const <Shift>[];
              return _MonthGrid(
                month: month,
                startGrid: startGrid,
                shifts: shifts,
                workplaces: workplaces,
              );
            },
          ),
        ),
      ],
    );
  }
}

class _WeekHeader extends StatelessWidget {
  const _WeekHeader();

  @override
  Widget build(BuildContext context) {
    const days = ['LUN', 'MAR', 'MIÉ', 'JUE', 'VIE', 'SÁB', 'DOM'];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(
        children: [
          for (final d in days)
            Expanded(
              child: Center(
                child: Text(
                  d,
                  style: Theme.of(context).textTheme.labelMedium?.copyWith(fontWeight: FontWeight.w800),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _MonthGrid extends StatelessWidget {
  const _MonthGrid({
    required this.month,
    required this.startGrid,
    required this.shifts,
    required this.workplaces,
  });

  final DateTime month;
  final DateTime startGrid;
  final List<Shift> shifts;
  final List<Workplace> workplaces;

  @override
  Widget build(BuildContext context) {
    // Build a map of slices per day (so shifts can "spill" into next day as a partial fill).
    final slicesByDay = <DateTime, List<_DaySlice>>{};
    final wpById = {for (final w in workplaces) w.id: w};

    final gridStart = startGrid;
    final gridEnd = startGrid.add(const Duration(days: 42));

    for (final s in shifts) {
      final sStart = s.start.isBefore(gridStart) ? gridStart : s.start;
      final sEnd = s.end.isAfter(gridEnd) ? gridEnd : s.end;
      if (!sEnd.isAfter(sStart)) continue;

      var dayCursor = DateTime(sStart.year, sStart.month, sStart.day);
      final lastDay = DateTime(sEnd.year, sEnd.month, sEnd.day);

      while (!dayCursor.isAfter(lastDay)) {
        final dayStart = DateTime(dayCursor.year, dayCursor.month, dayCursor.day);
        final dayEnd = dayStart.add(const Duration(days: 1));

        final sliceStart = sStart.isAfter(dayStart) ? sStart : dayStart;
        final sliceEnd = sEnd.isBefore(dayEnd) ? sEnd : dayEnd;

        if (sliceEnd.isAfter(sliceStart)) {
          final startMin = sliceStart.difference(dayStart).inMinutes.clamp(0, 24 * 60);
          final endMin = sliceEnd.difference(dayStart).inMinutes.clamp(0, 24 * 60);
          final key = DateTime(dayCursor.year, dayCursor.month, dayCursor.day);
          final wp = wpById[s.workplaceId]!;
          slicesByDay.putIfAbsent(key, () => []).add(
                _DaySlice(shift: s, workplace: wp, startMin: startMin, endMin: endMin, day: key),
              );
        }

        dayCursor = dayCursor.add(const Duration(days: 1));
      }
    }

    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 12),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 7,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
        childAspectRatio: 0.82,
      ),
      itemCount: 42,
      itemBuilder: (context, index) {
        final day = startGrid.add(Duration(days: index));
        final isInMonth = day.month == month.month;
        final key = DateTime(day.year, day.month, day.day);
        final slices = slicesByDay[key] ?? const <_DaySlice>[];
        final sorted = [...slices]..sort((a, b) => a.startMin.compareTo(b.startMin));
        return _DayCell(
          date: day,
          inMonth: isInMonth,
          slices: sorted,
          workplaces: workplaces,
        );
      },
    );
  }
}

class _DayCell extends StatelessWidget {
  const _DayCell({
    required this.date,
    required this.inMonth,
    required this.slices,
    required this.workplaces,
  });

  final DateTime date;
  final bool inMonth;
  final List<_DaySlice> slices;
  final List<Workplace> workplaces;

  static const _minutesPerDay = 24 * 60;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final bg = inMonth ? scheme.surfaceContainerLowest : scheme.surfaceContainerLow;

    final todayKey = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day);
    final isToday = DateTime(date.year, date.month, date.day) == todayKey;

    final border = isToday
        ? Border.all(color: scheme.primary, width: 1.8)
        : Border.all(color: scheme.outlineVariant.withOpacity(0.35), width: 1);

    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onLongPress: () {
        final iso = '${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
        GoRouter.of(context).push('/shift/new?date=$iso');
      },
      child: Container(
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(14),
          border: border,
        ),
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${date.day}',
              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    fontWeight: FontWeight.w900,
                    color: inMonth ? scheme.onSurface : scheme.onSurface.withOpacity(0.45),
                  ),
            ),
            const SizedBox(height: 8),
            if (slices.isEmpty)
              const Spacer()
            else
              _TimelineBars(day: date, slices: slices, workplaces: workplaces),
          ],
        ),
      ),
    );
  }
}

class _TimelineBars extends StatelessWidget {
  const _TimelineBars({required this.day, required this.slices, required this.workplaces});

  final DateTime day;
  final List<_DaySlice> slices;
  final List<Workplace> workplaces;

  static const minutesPerDay = 24 * 60;

  @override
  Widget build(BuildContext context) {
    // Greedy track assignment to show overlaps as stacked rows
    final ordered = [...slices]..sort((a, b) => a.startMin.compareTo(b.startMin));
    final tracks = <List<_DaySlice>>[];
    final trackEnds = <int>[];

    for (final s in ordered) {
      var placed = false;
      for (var i = 0; i < tracks.length; i++) {
        if (trackEnds[i] <= s.startMin) {
          tracks[i].add(s);
          trackEnds[i] = s.endMin;
          placed = true;
          break;
        }
      }
      if (!placed) {
        tracks.add([s]);
        trackEnds.add(s.endMin);
      }
    }

    final visibleTracks = tracks.take(2).toList();
    final hiddenCount = tracks.length - visibleTracks.length;

    // Unique shifts for bottom sheet if needed
    final uniqueShifts = <int, Shift>{};
    for (final s in slices) {
      uniqueShifts[s.shift.id] = s.shift;
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        const rowH = 7.0;
        const gap = 3.0;
        final barHeight = visibleTracks.isEmpty ? rowH : (visibleTracks.length * rowH + (visibleTracks.length - 1) * gap);

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: barHeight,
              child: Stack(
                children: [
                  // track backgrounds
                  for (var row = 0; row < visibleTracks.length; row++)
                    Positioned(
                      left: 0,
                      top: row * (rowH + gap),
                      width: width,
                      height: rowH,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(0.35),
                          borderRadius: BorderRadius.circular(999),
                        ),
                      ),
                    ),

                  // segments
                  for (var row = 0; row < visibleTracks.length; row++)
                    for (final slice in visibleTracks[row])
                      Positioned(
                        left: width * (slice.startMin / minutesPerDay),
                        top: row * (rowH + gap),
                        width: (width * (slice.durationMin / minutesPerDay)).clamp(2.0, width),
                        height: rowH,
                        child: GestureDetector(
                          onTap: () => GoRouter.of(context).push('/shift/${slice.shift.id}'),
                          child: Container(
                            decoration: BoxDecoration(
                              color: slice.workplace.color.withOpacity(0.88),
                              borderRadius: BorderRadius.circular(999),
                            ),
                          ),
                        ),
                      ),
                ],
              ),
            ),
            if (hiddenCount > 0) ...[
              const SizedBox(height: 8),
              InkWell(
                borderRadius: BorderRadius.circular(999),
                onTap: () => showModalBottomSheet(
                  context: context,
                  showDragHandle: true,
                  builder: (_) => _DayEventsSheet(
                    date: day,
                    shifts: uniqueShifts.values.toList()..sort((a, b) => a.start.compareTo(b.start)),
                    workplaces: workplaces,
                  ),
                ),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(999),
                    color: Theme.of(context).colorScheme.secondaryContainer,
                  ),
                  child: Text('+$hiddenCount', style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w900)),
                ),
              ),
            ],
          ],
        );
      },
    );
  }
}

class _DayEventsSheet extends StatelessWidget {
  const _DayEventsSheet({required this.date, required this.shifts, required this.workplaces});
  final DateTime date;
  final List<Shift> shifts;
  final List<Workplace> workplaces;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              fmtDateLong(date),
              style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 10),
            for (final s in shifts)
              ListTile(
                leading: _WorkBadge(w: workplaces.firstWhere((x) => x.id == s.workplaceId)),
                title: Text(_title(workplaces.firstWhere((x) => x.id == s.workplaceId), s)),
                subtitle: Text(fmtRangeWithDay(s.start, s.end)),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.of(context).pop();
                  GoRouter.of(context).push('/shift/${s.id}');
                },
              )
          ],
        ),
      ),
    );
  }

  String _title(Workplace w, Shift s) {
    final range = fmtRange(s.start, s.end);
    if (w.alias == 'EMER' && s.type == ShiftType.custom) return '🚑 EMERGENCIA $range';
    if (s.type == ShiftType.h24) return '${w.alias} 24h $range';
    if (s.type == ShiftType.h12Night) return '${w.alias} 🌙 $range';
    return '${w.alias} $range';
  }
}

class _WorkBadge extends StatelessWidget {
  const _WorkBadge({required this.w});
  final Workplace w;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 44,
      height: 44,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: w.color.withOpacity(0.18),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        w.alias,
        style: Theme.of(context).textTheme.labelLarge?.copyWith(fontWeight: FontWeight.w900, color: w.color),
      ),
    );
  }
}

class _AgendaView extends ConsumerWidget {
  const _AgendaView({required this.workplaces});
  final List<Workplace> workplaces;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final upcomingAsync = ref.watch(upcomingShiftsProvider);

    return upcomingAsync.when(
      data: (list) {
        if (list.isEmpty) return const Center(child: Text('No hay guardias próximas'));
        final groups = <DateTime, List<Shift>>{};
        for (final s in list) {
          final k = DateTime(s.start.year, s.start.month, s.start.day);
          groups.putIfAbsent(k, () => []).add(s);
        }
        final keys = groups.keys.toList()..sort();
        return ListView(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 20),
          children: [
            for (final day in keys) ...[
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
                child: Text(fmtDateLong(day), style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900)),
              ),
              for (final s in groups[day]!)
                _AgendaTile(shift: s, workplace: workplaces.firstWhere((w) => w.id == s.workplaceId)),
            ]
          ],
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Padding(padding: const EdgeInsets.all(16), child: Text('Error: $e')),
    );
  }
}

class _AgendaTile extends StatelessWidget {
  const _AgendaTile({required this.shift, required this.workplace});
  final Shift shift;
  final Workplace workplace;

  @override
  Widget build(BuildContext context) {
    final title = (workplace.alias == 'EMER' && shift.type == ShiftType.custom)
        ? '🚑 EMERGENCIA ${fmtRange(shift.start, shift.end)}'
        : '${workplace.alias}${shift.type == ShiftType.h12Night ? " 🌙" : ""} ${fmtRange(shift.start, shift.end)}';

    return Card(
      margin: const EdgeInsets.fromLTRB(8, 6, 8, 6),
      child: ListTile(
        leading: Container(
          width: 10,
          height: double.infinity,
          decoration: BoxDecoration(
            color: workplace.color,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
        title: Text(title, style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w900)),
        subtitle: Text(workplace.name),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => GoRouter.of(context).push('/shift/${shift.id}'),
      ),
    );
  }
}
