import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:intl/date_symbol_data_local.dart';

import 'data/db.dart';
import 'data/seed.dart';
import 'services/notifications.dart';

Future<void> bootstrap(ProviderContainer container) async {
  tz.initializeTimeZones();

  // Required for DateFormat('...', 'es') in release builds
  await initializeDateFormatting('es');

  final db = container.read(appDbProvider);
  await db.init();
  await seedIfNeeded(db);

  final notifications = container.read(notificationsServiceProvider);
  await notifications.init();
}
