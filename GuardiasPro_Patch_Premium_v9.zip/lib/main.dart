import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'src/app.dart';
import 'src/bootstrap.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // In release, uncaught framework errors can look like a "blank screen".
  // This makes them visible and keeps the app responsive.
  ErrorWidget.builder = (FlutterErrorDetails details) {
    return Material(
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: ListView(
            children: [
              const Text('Guardias Pro — Error', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              const Text('Se produjo un error inesperado.'),
              const SizedBox(height: 12),
              Text(details.exceptionAsString(), style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 12),
              const Text('Sugerencia: cerrá y volvé a abrir la app. Si persiste, actualizá a la última versión.'),
            ],
          ),
        ),
      ),
    );
  };

  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.dumpErrorToConsole(details);
  };

  await runZonedGuarded(() async {
    final container = ProviderContainer();
    await bootstrap(container);

    // Catch async platform errors too.
    PlatformDispatcher.instance.onError = (error, stack) {
      // Keep app alive; error will be surfaced by ErrorWidget if it reaches the UI.
      return true;
    };

    runApp(UncontrolledProviderScope(container: container, child: const GuardiasProApp()));
  }, (error, stack) {
    // Last-resort guard.
  });
}
