import 'dart:async';
import 'dart:convert';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'db.dart';
import 'models.dart';

final workplacesProvider = FutureProvider<List<Workplace>>((ref) async {
  final db = ref.read(appDbProvider);
  return db.getWorkplaces();
});

final templatesProvider = FutureProvider<List<ShiftTemplate>>((ref) async {
  final db = ref.read(appDbProvider);
  return db.getTemplates();
});

final alertDefaultsProvider = FutureProvider<Map<ShiftType, List<int>>>((ref) async {
  final db = ref.read(appDbProvider);
  final raw = await db.getKv('alert_defaults');
  if (raw == null) return const {};
  final map = jsonDecode(raw) as Map<String, dynamic>;
  List<int> parseList(dynamic v) => (v as List).map((e) => (e as num).toInt()).toList();
  return {
    ShiftType.h24: parseList(map['h24']),
    ShiftType.h12Day: parseList(map['h12Day']),
    ShiftType.h12Night: parseList(map['h12Night']),
    ShiftType.custom: parseList(map['custom']),
  };
});

final upcomingShiftsProvider = FutureProvider<List<Shift>>((ref) async {
  final db = ref.read(appDbProvider);
  return db.getUpcomingShifts(DateTime.now());
});

final nextShiftProvider = FutureProvider<Shift?>((ref) async {
  final list = await ref.watch(upcomingShiftsProvider.future);
  if (list.isEmpty) return null;
  return list.first;
});
