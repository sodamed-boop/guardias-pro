import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../ui/shell/shell_screen.dart';
import '../ui/dashboard/dashboard_screen.dart';
import '../ui/calendar/calendar_screen.dart';
import '../ui/templates/templates_screen.dart';
import '../ui/settings/settings_screen.dart';
import '../ui/shifts/shift_editor_screen.dart';
import '../ui/shifts/shift_detail_screen.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/home',
    routes: [
      ShellRoute(
        builder: (context, state, child) => ShellScreen(child: child),
        routes: [
          GoRoute(path: '/home', builder: (c, s) => const DashboardScreen()),
          GoRoute(path: '/calendar', builder: (c, s) => const CalendarScreen()),
          GoRoute(path: '/templates', builder: (c, s) => const TemplatesScreen()),
          GoRoute(path: '/settings', builder: (c, s) => const SettingsScreen()),
        ],
      ),
      GoRoute(
        path: '/shift/new',
        builder: (c, s) {
          final prefillDateIso = s.uri.queryParameters['date'];
          final workplaceId = int.tryParse(s.uri.queryParameters['workplaceId'] ?? '');
          return ShiftEditorScreen(prefillDateIso: prefillDateIso, prefillWorkplaceId: workplaceId);
        },
      ),
      GoRoute(
        path: '/shift/:id',
        builder: (c, s) {
          final id = int.parse(s.pathParameters['id']!);
          return ShiftDetailScreen(shiftId: id);
        },
      ),
      GoRoute(
        path: '/shift/:id/edit',
        builder: (c, s) {
          final id = int.parse(s.pathParameters['id']!);
          return ShiftEditorScreen(editShiftId: id);
        },
      ),
    ],
    errorBuilder: (c, s) => Scaffold(
      appBar: AppBar(title: const Text('Error')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Text(s.error.toString()),
      ),
    ),
  );
});
