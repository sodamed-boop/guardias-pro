import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/db.dart';
import '../../data/models.dart';
import '../../data/providers.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final defaultsAsync = ref.watch(alertDefaultsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Ajustes')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Text(
            'Alertas por tipo',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          defaultsAsync.when(
            data: (map) => Column(
              children: [
                _AlertRow(type: ShiftType.h24, values: map[ShiftType.h24] ?? const [1440, 180]),
                _AlertRow(type: ShiftType.h12Day, values: map[ShiftType.h12Day] ?? const [720, 120]),
                _AlertRow(type: ShiftType.h12Night, values: map[ShiftType.h12Night] ?? const [720, 60]),
                _AlertRow(type: ShiftType.custom, values: map[ShiftType.custom] ?? const [120, 30]),
                const SizedBox(height: 10),
                FilledButton.icon(
                  onPressed: () => _editDefaults(context, ref, map),
                  icon: const Icon(Icons.edit_outlined),
                  label: const Text('Editar defaults'),
                ),
              ],
            ),
            loading: () => const Padding(
              padding: EdgeInsets.all(16),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (e, _) => Text('Error: $e'),
          ),
          const SizedBox(height: 20),
          Text(
            'Ayuda: si no llegan alertas',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(14),
              child: Text(
                """En algunos teléfonos el ahorro de batería puede frenar notificaciones.
• Ajustes → Apps → Guardias Pro → Notificaciones: permitir.
• Ajustes → Batería → Ahorro/Optimización: excluir Guardias Pro.
• Si usás “No molestar”, agregá una excepción.
""",
              ),
            ),
          ),
        ],
      ),
    );
  }

  static Future<void> _editDefaults(BuildContext context, WidgetRef ref, Map<ShiftType, List<int>> current) async {
    final result = await showDialog<Map<ShiftType, List<int>>>(
      context: context,
      builder: (_) => _EditDefaultsDialog(current: current),
    );
    if (result == null) return;

    final db = ref.read(appDbProvider);
    final payload = {
      'h24': result[ShiftType.h24] ?? const [1440, 180],
      'h12Day': result[ShiftType.h12Day] ?? const [720, 120],
      'h12Night': result[ShiftType.h12Night] ?? const [720, 60],
      'custom': result[ShiftType.custom] ?? const [120, 30],
    };
    await db.putKv('alert_defaults', jsonEncode(payload));
    ref.invalidate(alertDefaultsProvider);

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Defaults actualizados (se aplican a nuevas guardias).')),
      );
    }
  }
}

class _AlertRow extends StatelessWidget {
  const _AlertRow({required this.type, required this.values});
  final ShiftType type;
  final List<int> values;

  @override
  Widget build(BuildContext context) {
    final label = shiftTypeLabel(type);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Expanded(
              child: Text(
                label,
                style: Theme.of(context).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w800),
              ),
            ),
            Text(values.map(_fmt).join(' · '), style: Theme.of(context).textTheme.bodyMedium),
          ],
        ),
      ),
    );
  }

  String _fmt(int minutes) {
    final h = minutes ~/ 60;
    final m = minutes % 60;
    if (m == 0) return '${h}h';
    if (h == 0) return '${m}m';
    return '${h}h ${m}m';
  }
}

class _EditDefaultsDialog extends StatefulWidget {
  const _EditDefaultsDialog({required this.current});
  final Map<ShiftType, List<int>> current;

  @override
  State<_EditDefaultsDialog> createState() => _EditDefaultsDialogState();
}

class _EditDefaultsDialogState extends State<_EditDefaultsDialog> {
  late final TextEditingController _h24;
  late final TextEditingController _d12;
  late final TextEditingController _n12;
  late final TextEditingController _custom;

  @override
  void initState() {
    super.initState();
    _h24 = TextEditingController(text: (widget.current[ShiftType.h24] ?? const [1440, 180]).join(','));
    _d12 = TextEditingController(text: (widget.current[ShiftType.h12Day] ?? const [720, 120]).join(','));
    _n12 = TextEditingController(text: (widget.current[ShiftType.h12Night] ?? const [720, 60]).join(','));
    _custom = TextEditingController(text: (widget.current[ShiftType.custom] ?? const [120, 30]).join(','));
  }

  @override
  void dispose() {
    _h24.dispose();
    _d12.dispose();
    _n12.dispose();
    _custom.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Editar defaults de alertas'),
      content: SingleChildScrollView(
        child: Column(
          children: [
            _field('24h (min antes)', _h24, hint: '1440,180'),
            _field('12h Día (min antes)', _d12, hint: '720,120'),
            _field('12h Noche (min antes)', _n12, hint: '720,60'),
            _field('Personalizada (min antes)', _custom, hint: '120,30'),
            const SizedBox(height: 8),
            const Text('Formato: minutos antes separados por coma. Ej: 1440,180'),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancelar')),
        FilledButton(
          onPressed: () {
            final out = <ShiftType, List<int>>{
              ShiftType.h24: _parse(_h24.text),
              ShiftType.h12Day: _parse(_d12.text),
              ShiftType.h12Night: _parse(_n12.text),
              ShiftType.custom: _parse(_custom.text),
            };
            Navigator.pop(context, out);
          },
          child: const Text('Guardar'),
        ),
      ],
    );
  }

  Widget _field(String label, TextEditingController c, {required String hint}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: c,
        keyboardType: TextInputType.text,
        decoration: InputDecoration(labelText: label, hintText: hint),
      ),
    );
  }

  List<int> _parse(String raw) {
    return raw
        .split(',')
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty)
        .map((s) => int.tryParse(s) ?? 0)
        .where((v) => v > 0)
        .toList();
  }
}
